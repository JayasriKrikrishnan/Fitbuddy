import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("GOOGLE_API_KEY")
if API_KEY:
    genai.configure(api_key=API_KEY)

MODEL_NAME = os.getenv("GEMINI_PRO_MODEL", "gemini-1.5-pro")

def update_workout_plan(original_plan, feedback):
    if not API_KEY:
        raise RuntimeError("GOOGLE_API_KEY is not configured. Add it to .env.")
    model = genai.GenerativeModel(MODEL_NAME)
    prompt = f"""Update this existing 7-day fitness plan.

Original plan:
{original_plan}

User feedback:
{feedback}

Return a revised 7-day plan that applies the feedback while keeping a clear day-by-day structure, exercises, sets/reps or duration, rest guidance, and recovery guidance. Do not make medical claims."""
    return model.generate_content(prompt).text
