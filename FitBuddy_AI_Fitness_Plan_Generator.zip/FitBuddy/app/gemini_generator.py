import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("GOOGLE_API_KEY")
if API_KEY:
    genai.configure(api_key=API_KEY)

MODEL_NAME = os.getenv("GEMINI_PRO_MODEL", "gemini-1.5-pro")

def generate_workout_gemini(username, age, weight, goal, intensity):
    if not API_KEY:
        raise RuntimeError("GOOGLE_API_KEY is not configured. Add it to .env.")
    model = genai.GenerativeModel(MODEL_NAME)
    prompt = f"""Create a personalized 7-day fitness plan for:
Name: {username}
Age: {age}
Weight: {weight} kg
Fitness goal: {goal}
Workout intensity: {intensity}

For each day include focus, warm-up (5-10 minutes), main workout with exercises and sets/reps or duration, rest guidance, and cooldown/recovery tip. Keep it practical and structured. Do not make medical claims."""
    return model.generate_content(prompt).text
