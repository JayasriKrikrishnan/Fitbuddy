import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("GOOGLE_API_KEY")
if API_KEY:
    genai.configure(api_key=API_KEY)

MODEL_NAME = os.getenv("GEMINI_FLASH_MODEL", "gemini-1.5-flash")

def generate_nutrition_tip_with_flash(goal):
    if not API_KEY:
        raise RuntimeError("GOOGLE_API_KEY is not configured. Add it to .env.")
    model = genai.GenerativeModel(MODEL_NAME)
    prompt = f"""Give one concise, practical nutrition or recovery tip for someone whose fitness goal is {goal}. Give a simple action. Keep it general wellness guidance and avoid medical claims."""
    return model.generate_content(prompt).text
