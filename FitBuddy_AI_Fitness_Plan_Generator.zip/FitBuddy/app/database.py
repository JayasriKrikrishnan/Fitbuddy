from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = "sqlite:///./fitbuddy.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def save_user(db, user_data):
    from .models import User
    user = User(**user_data)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

def save_plan(db, user, plan, nutrition_tip):
    user.original_plan = plan
    user.nutrition_tip = nutrition_tip
    db.commit()
    db.refresh(user)
    return user

def get_user(db, user_id):
    from .models import User
    return db.query(User).filter(User.user_id == user_id).first()

def update_plan(db, user_id, updated_plan):
    user = get_user(db, user_id)
    if user:
        user.updated_plan = updated_plan
        db.commit()
        db.refresh(user)
    return user

def get_all_users(db):
    from .models import User
    return db.query(User).order_by(User.id.desc()).all()

def delete_user(db, user_id):
    user = get_user(db, user_id)
    if user:
        db.delete(user)
        db.commit()
        return True
    return False
