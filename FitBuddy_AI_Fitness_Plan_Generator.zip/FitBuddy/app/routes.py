from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from .database import SessionLocal, save_user, save_plan, get_user, get_all_users, update_plan, delete_user
from .gemini_generator import generate_workout_gemini
from .gemini_flash_generator import generate_nutrition_tip_with_flash
from .updated_plan import update_workout_plan
from .schemas import UserInput, FeedbackRequest

router = APIRouter()
templates = Jinja2Templates(directory="templates")

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(request: Request, username: str = Form(...), user_id: str = Form(...),
                     age: int = Form(...), weight: float = Form(...), goal: str = Form(...),
                     intensity: str = Form(...)):
    try:
        data = UserInput(username=username, user_id=user_id, age=age, weight=weight,
                         goal=goal, intensity=intensity)
        plan = generate_workout_gemini(data.username, data.age, data.weight, data.goal, data.intensity)
        tip = generate_nutrition_tip_with_flash(data.goal)
        db = SessionLocal()
        try:
            user = get_user(db, data.user_id)
            if user:
                user.username, user.age, user.weight = data.username, data.age, data.weight
                user.goal, user.intensity = data.goal, data.intensity
                user.original_plan, user.updated_plan, user.nutrition_tip = plan, None, tip
                db.commit()
                db.refresh(user)
            else:
                user = save_user(db, data.model_dump())
                user = save_plan(db, user, plan, tip)
        finally:
            db.close()
        return templates.TemplateResponse("result.html", {
            "request": request, "user": user, "workout_plan": plan,
            "nutrition_tip": tip, "message": None
        })
    except Exception as exc:
        return templates.TemplateResponse("index.html", {"request": request, "error": str(exc)}, status_code=500)

@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(request: Request, user_id: str = Form(...), feedback: str = Form(...)):
    db = SessionLocal()
    user = None
    try:
        user = get_user(db, user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User ID not found")
        payload = FeedbackRequest(user_id=user_id, feedback=feedback)
        updated = update_workout_plan(user.original_plan, payload.feedback)
        user = update_plan(db, user_id, updated)
        return templates.TemplateResponse("result.html", {
            "request": request, "user": user, "workout_plan": updated,
            "nutrition_tip": user.nutrition_tip,
            "message": "Your workout plan has been updated successfully."
        })
    except HTTPException:
        raise
    except Exception as exc:
        return templates.TemplateResponse("result.html", {
            "request": request, "user": user, "workout_plan": None,
            "nutrition_tip": None, "message": f"Error updating plan: {exc}"
        }, status_code=500)
    finally:
        db.close()

@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request):
    db = SessionLocal()
    try:
        return templates.TemplateResponse("all_users.html", {
            "request": request, "users": get_all_users(db)
        })
    finally:
        db.close()

@router.post("/delete-user/{user_id}")
def remove_user(user_id: str):
    db = SessionLocal()
    try:
        delete_user(db, user_id)
        return RedirectResponse("/view-all-users", status_code=303)
    finally:
        db.close()
