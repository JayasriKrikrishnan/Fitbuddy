# FitBuddy – AI Fitness Plan Generator using Gemini Models

## Setup
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Put your Gemini API key in `.env`, then run:
```bash
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000 and API docs at http://127.0.0.1:8000/docs.

## Structure
- `app/main.py` – FastAPI application
- `app/routes.py` – routes and form processing
- `app/database.py` – SQLite/SQLAlchemy helpers
- `app/gemini_generator.py` – 7-day workout generation
- `app/gemini_flash_generator.py` – nutrition/recovery tip
- `app/updated_plan.py` – feedback-based plan update
- `templates/` – Jinja2 pages
- `static/` – CSS
